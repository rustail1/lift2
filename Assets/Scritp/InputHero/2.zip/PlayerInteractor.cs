using UnityEngine;

[DisallowMultipleComponent]
public class PlayerInteractor : MonoBehaviour
{
    [SerializeField] private Camera _camera;
    [SerializeField] private float _distance = 2.5f;
    [SerializeField] private LayerMask _interactionMask = ~0;

    [Header("Debug")]
    [SerializeField] private string _currentInteractionText;
    [SerializeField] private bool _hasCurrent;

    private IInteractable _current;

    private void Reset()
    {
        if (_camera == null)
            _camera = Camera.main != null ? Camera.main : GetComponentInChildren<Camera>();
    }

    // Вызывается из LiftGameInitializer. Awake специально не используется.
    public void Initialize()
    {
        if (_camera == null)
            _camera = Camera.main != null ? Camera.main : GetComponentInChildren<Camera>();
    }

    // Вызывается из LiftGameUpdateRunner. Update специально не используется.
    public void Tick()
    {
        UpdateCurrentInteractable();
        UpdateInteractionUI();
    }

    public void InteractDown()
    {
        if (_current == null)
            return;

        _current.InteractDown();
    }

    public void InteractUp()
    {
        _current?.InteractUp();
    }

    private void UpdateCurrentInteractable()
    {
        _current = null;
        _hasCurrent = false;
        _currentInteractionText = string.Empty;

        if (_camera == null)
            return;

        Ray ray = new Ray(_camera.transform.position, _camera.transform.forward);

        if (Physics.Raycast(ray, out RaycastHit hit, _distance, _interactionMask))
        {
            _current = hit.collider.GetComponentInParent<IInteractable>();

            if (_current != null)
            {
                _hasCurrent = true;
                _currentInteractionText = _current.GetInteractionText();
            }
        }
    }

    private void UpdateInteractionUI()
    {
        InteractionUIService ui = InteractionUIService.Instance;
        if (ui == null)
            return;

        bool active = _current != null;
        ui.SetInteractionTarget(active, active ? _currentInteractionText : string.Empty);

        if (_current == null)
        {
            ui.SetHoldProgress(0f);
            ui.SetMashProgress(0f);
            return;
        }

        float progress = _current.GetInteractionProgress();
        InteractionType type = _current.GetInteractionType();

        ui.SetHoldProgress(type == InteractionType.Hold && _current.IsInteractionInProgress ? progress : 0f);
        ui.SetMashProgress(type == InteractionType.Mash ? progress : 0f);
    }
}
